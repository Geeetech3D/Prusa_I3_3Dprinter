#pragma once
//the following defines reconfigure marlin for the listed model & features. anything with a // is commented out and disabled if you remove the // you are enabling it.
//Compile with latest Arduino ide V1.9 select atmega2650 and check that your printer port is selected make sure U8glib is installed in the library menu. 
//For the flash process be sure to close any other program that controls the printer failure to do so can brick the printer. 
//Note:the default setup is for the machine this was tested on you will need to reconfigure below.

//Step 1 uncomment 1 model - these enable every setting for this model not just the board - GTA30 config in "verts_experiments" folder with calibration stl files
#define GTA10 //A10 Variant
//#define GTA20 //A20 Variant
//#define MECREATOR2 //Mecreator2
//#define I3PROW //i3prow & i3proa *untested*
//#define GTA30 //A30 *experemimental*

//Step 2 uncomment probe if you have one, if you have a 5V probe enable VMSM.
#define Probe // Enable 3dtouch/bltouch support else use manual if disabled.
//#define VMSM // Enable Voltage mode selection menu (DANGER: Applying 5V to a probe that isnt 5V will break it). 

//Step 3 Drivers section enable = tmc/drv(mod)/disable  all= a4988(stock) 
#define TMC2208    // Enable TMC2208 / Disable for A4988(Stock)
//#define TMC2208I   // Enable TMC2208 inverted/ Disable for A4988(Stock)
//#define DRV8825    // Enable DRV8825 / Disable for A4988(Stock)
 
//Step 4 uncomment only 1 if you have mix/2in1 variant
//#define MIX     //Enable Mixing support - Virtual Motor Control - Unsupported by slicers - Supports PLR
//#define CYCLOPS //Enable Alternative to mixing - Physical Motor Control - Supported by slicers - No PLR 

//Step 5 uncomment only the features you intend to use
#define SDCARD // Enable SDcard support - Costs over 1000 Bytes dynamic memory
//#define PLR    // Enable Power loss resume - Costs over 500 Bytes dynamic memory. (Gimmick feature)
//#define RUNOUT // Enable Filament runout support - Some of the sensors are uninverted. (Gimmick feature)
//#define FRI    // Enable Filament runout inversion to Uninvert Runout sensor only used if RUNOUT enabled.
//#define LEDHEADER // Enable LED control menu for use with the led header on the board (mecreator2 stock has this setup)
//#define PRINTSTATS // Enable print statistical menu.
//#define ACTION // Enable Action Commands that dont do much and can cause problems.

//Below this line are more advanced configurations for special situations.

#define BUILDNUMBER "Build 333" //Source updated on May/30

//Enabled Single TMC2208 Per Axis True=TMC2208 False=A4988
#if ENABLED (TMC2208) or ENABLED (TMC2208I)
  #define TMC2208_X true //false
  #define TMC2208_Y true //false
  #define TMC2208_Z true //fasle
  #define TMC2208_E0 true //false
  #define TMC2208_E1 true //fasle
#endif

//These defines need have to be enabled but there value can be edited the higher these values are the more dynamic memory they use.
#define GCODEBUFFER 4 //Size of serial buffer default 4 - octopi users may want this larger to prevent slowdown due to cpu lag.
#define GRIDSIZE 7    //Mesh grid size XY for all bed leveling max 15, defualt 7x7=49 point mesh 
#define MPE 5         //Min probe Edge/Mesh inset - adjusts mesh this many mm from the edge all sides
 
//Adjust probe offsets if needed else leave alone only used if probe is enabled
#define XPROBEOFFSET -37   //x offset 3Dtouch -37 BLtouch -40 with stock mount on A10/A20 other models will very
#define YPROBEOFFSET 0   //y offset
#define ZPROBEOFFSET 0   //if you put your z offset here it will be hardcoded

//This Build consists of files Build.h/Configuration.h/Configuration_adv.h & the folder "vertabreakers_experiments" + Marlin 2 source code as the framework.
//(CodeName:1 Config To Rule Them All) Discord:https://discord.gg/9q24GaX Youtube:https://www.youtube.com/c/Vertabreaker Forum:http://www.geeetech.com/forum/viewtopic.php?f=20&t=68651
